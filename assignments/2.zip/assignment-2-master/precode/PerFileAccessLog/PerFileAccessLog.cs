using System;
using System.IO;
using System.Text;

namespace PerFileAccessLog
{
    /// <summary>
    /// This program generates a per file access log.
    /// The output of size corresponding to argument one is put in the file given by argument two.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                string appname = System.AppDomain.CurrentDomain.FriendlyName;
                Console.WriteLine($"Usage: {appname} [size-in-megabytes] [output-file], e.g. {appname} 1000 myoutputfile.tsv");
                return;
            }

            int sizeInMb = -1;
            if (!int.TryParse(args[0], out sizeInMb) || sizeInMb < 1)
            {
                Console.WriteLine("Unable to parse size argument. Should be positive integer.");
                return;
            }

            string outputFile = args[1];

            int sizeInBytes = sizeInMb * 1024 * 1024;
            var date = new DateTime(2018, 1, 1);
            var random = new Random();
            long bytes = 0;
            using (FileStream outfile = File.Open(outputFile, FileMode.CreateNew))
            {
                while (bytes < sizeInBytes)
                {
                    int numEntriesForDate = random.Next(0, 500000);
                    for (int i = 0; i < numEntriesForDate; i++)
                    {
                        var logEntry = new PerFileLogEntry(date);
                        byte[] entryBytes = Encoding.UTF8.GetBytes(logEntry.ToString());
                        outfile.Write(entryBytes, 0, entryBytes.Length);

                        bytes += entryBytes.Length;
                        if (bytes >= sizeInBytes)
                        {
                            break;
                        }
                    }
                    date = date.AddDays(1);
                }
            }
        }
    }
}
