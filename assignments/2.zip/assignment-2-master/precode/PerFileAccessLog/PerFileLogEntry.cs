using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using Util;

namespace PerFileAccessLog
{
    /// <summary>
    /// Represents a log entry in the per-file logs.
    /// Used in exercise 3.
    /// </summary>
    public class PerFileLogEntry
    {
        private readonly DateTime Date;
        private readonly string Region;
        private readonly string TenantName;
        private readonly string FileName;
        private readonly string ModifyingUsers;
        private readonly DateTime FirstAccess;
        private readonly DateTime LastAccess;

        private static readonly Bogus.DataSets.Company FakeCompanies = new Bogus.DataSets.Company();
        private static readonly Bogus.DataSets.System FakeSystem = new Bogus.DataSets.System();
        private static readonly Bogus.DataSets.Internet FakeInternet = new Bogus.DataSets.Internet();

        private readonly string formatString = "{0:s}\t{1}\t{2}\t{3}\t{4}\t{5:s}\t{6:s}" + Environment.NewLine;

        /// <summary>
        /// Creates a per-file log entry for the given date.
        /// </summary>
        /// <param name="date">The date for which the log entry should be created.</param>
        public PerFileLogEntry(DateTime date)
        {
            var random = new Random();
            Date = date.Date;
            Region = DataGeneration.GetRegion();
            TenantName = FakeCompanies.CompanyName();
            FileName = FakeSystem.FileName();
            ModifyingUsers = GenerateUsersString();
            FirstAccess = Date.AddHours(random.Next(0, 6))
                              .AddMinutes(random.Next(0, 59))
                              .AddSeconds(random.Next(0, 59));
            LastAccess = Date.AddHours(random.Next(18, 23))
                             .AddMinutes(random.Next(0, 59))
                             .AddSeconds(random.Next(0, 59));
        }

        /// <summary>
        /// Creates a string representing the log entry.
        /// </summary>
        /// <returns>The log entry in string form.</returns>
        public override string ToString()
        {
            return string.Format(formatString, Date, Region, TenantName, FileName,
                ModifyingUsers, FirstAccess, LastAccess);
        }

        /// <summary>
        /// Generates a JSON list representatin of a set of users represented by their email addresses.
        /// </summary>
        private static string GenerateUsersString()
        {
            var random = new Random();
            int numUsers = random.Next(1, 1000);
            return JsonConvert.SerializeObject(UserEmails(numUsers));
        }

        private static IEnumerable<string> UserEmails(int numUsers)
        {
            for (int i = 0; i < numUsers; i++)
            {
                yield return FakeInternet.Email();
            }
        }
    }
}
