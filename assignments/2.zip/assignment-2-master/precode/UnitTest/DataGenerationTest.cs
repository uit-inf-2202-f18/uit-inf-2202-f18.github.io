using System.Collections.Generic;
using System.Text.RegularExpressions;
using Util;
using Xunit;

namespace UtilTest
{
    public class DataGenerationTest
    {
        // This is a tricky test since it checks a random value.
        // Perhaps you can find a way to improve it!
        [Fact]
        public void Generates_a_random_region()
        {
            var validRegions = new List<string> { "EUR", "CAN", "JPN", "US", "CHN", "GER", "APAC", "AUS" };
            string region = DataGeneration.GetRegion();
            Assert.Contains(region, validRegions);
        }

        // This regular expression is not very exact, but it'll probably work
        private static readonly Regex pattern = new Regex("\"([-0-9a-f]{32,36})\"");

        [Theory(Skip = "Remove this skip statement when you have implemented GenerateStringClaims in the Util project")]
        [InlineData(0)]
        [InlineData(1)]
        [InlineData(13)]
        public void Generates_the_right_amount_of_guids(int num_guids)
        {
            // Ask for X guids in string format
            string guids = DataGeneration.GenerateStringClaims(num_guids);
            // Use a regular expression to find valid guid strings
            MatchCollection results = pattern.Matches(guids);
            // Assert that we found X matches
            Assert.Equal(num_guids, results.Count);
        }
    }
}
